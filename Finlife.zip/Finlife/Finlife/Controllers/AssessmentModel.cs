namespace Namespace
{
    internal class AssessmentModel
    {
        public List<string> Comments { get; internal set; } = null!;
    }
}