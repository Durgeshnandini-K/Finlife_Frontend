namespace Finlife.Controllers
{
    public class HttpPostedFileBase
    {
    }
}