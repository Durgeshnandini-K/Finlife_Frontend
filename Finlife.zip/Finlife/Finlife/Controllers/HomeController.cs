﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Finlife.Models;

namespace Finlife.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Login()
    {
        return View();
    }

    public IActionResult Signup()
    {
        return View();
    }


    public IActionResult Adminhomepage()
    {
        return View();
    }

    public IActionResult Managementhomepage()
    {
        return View();
    }
    public IActionResult Rolemanagementscreen()
    {
        return View();
    }
    public IActionResult Acceptrejectscreen()
    {
        return View();
    }
    public IActionResult Assessment()
    {
        return View();
    }

    public IActionResult Assessmentpart1report()
    {
        return View();
    }
    public IActionResult Assessmentpart2report()
    {
        return View();
    }
    public IActionResult Assessmentque1()
    {
        return View();
    }
        public IActionResult Assessmentque2()
    {
        return View();
    }
        public IActionResult Businessinfo()
    {
        return View();
    }
        public IActionResult Reassessment()
    {
        return View();
    }


    public IActionResult Assessmentquestionnairescreen()
    {
        return View();
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

